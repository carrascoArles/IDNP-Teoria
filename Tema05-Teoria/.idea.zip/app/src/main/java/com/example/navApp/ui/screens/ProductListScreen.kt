package com.example.navApp.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.navApp.model.Product
import com.example.navApp.ui.components.ProductCard

// Datos de ejemplo
val sampleProducts = listOf(
    Product(
        id = 1,
        name = "Laptop Gamer",
        price = 1299.99,
        description = "Laptop de alto rendimiento para gaming"
    ),
    Product(
        id = 2,
        name = "Smartphone Pro",
        price = 899.99,
        description = "Teléfono inteligente con cámara profesional"
    ),
    Product(
        id = 3,
        name = "Auriculares Bluetooth",
        price = 149.99,
        description = "Auriculares inalámbricos con cancelación de ruido"
    ),
    Product(
        id = 4,
        name = "Smart Watch",
        price = 299.99,
        description = "Reloj inteligente con monitor de salud"
    ),
    Product(
        id = 5,
        name = "Tablet Android",
        price = 459.99,
        description = "Tablet con pantalla HD y largo batería"
    )
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductListScreen(onProductClick: (Int) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Lista de Productos") }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Lista de productos
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(sampleProducts) { product ->
                    ProductCard(
                        product = product,
                        onClick = { onProductClick(product.id) }
                    )
                }
            }
        }
    }
}